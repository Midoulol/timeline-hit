/**
 * Electrobun configuration type definitions
 * Used in electrobun.config.ts files
 */

import type { WindowsWebView2Permission } from "./windowsPermissions";

type BundlerOptions = {
	external?: string[];
	define?: Record<string, string>;
	alias?: Record<string, string>;
	minify?: boolean;
	sourcemap?: boolean | "inline" | "external" | "linked";
	target?: string | string[];
};

type ViewBundlerOptions = BundlerOptions & {
	format?: "esm" | "cjs" | "iife";
};

type CarrotFileActivatorConfig = {
	baseName?: string;
	nodeType?: "file" | "dir" | "any";
	slate: {
		type: string;
		name?: string;
		icon?: string;
		config?: Record<string, unknown>;
	};
};

type CarrotContributionsConfig = {
	fileActivators?: CarrotFileActivatorConfig[];
};

type CarrotUIDefinition = {
	name?: string;
	entrypoint?: string;
	path?: string;
	[key: string]: unknown;
};

export interface ElectrobunConfig {
	/**
	 * Application metadata configuration
	 */
	app: {
		/**
		 * The display name of your application
		 */
		name: string;

		/**
		 * Unique identifier for your application (e.g., "com.example.myapp")
		 * Used for platform-specific identifiers
		 */
		identifier: string;

		/**
		 * Application version string (e.g., "1.0.0")
		 */
		version: string;

		/**
		 * Optional description of the application
		 */
		description?: string;

		/**
		 * Custom URL schemes to register for deep linking (e.g., ["myapp", "myapp-dev"])
		 * This allows your app to be opened via URLs like myapp://some/path
		 *
		 * Platform support:
		 * - macOS: Fully supported. App must be in /Applications folder for registration to work.
		 * - Windows: Not yet supported
		 * - Linux: Not yet supported
		 *
		 * To handle incoming URLs, listen for the "open-url" event:
		 * ```typescript
		 * Electrobun.events.on("open-url", (e) => {
		 *   console.log("Opened with URL:", e.data.url);
		 * });
		 * ```
		 */
		urlSchemes?: string[];

		/**
		 * File type associations for the application.
		 * Registers document types so the OS can open files with your app
		 * (e.g., double-click in Finder, "Open With" menu, drag-to-dock).
		 *
		 * Platform support:
		 * - macOS: Fully supported. Generates CFBundleDocumentTypes in Info.plist.
		 * - Windows/Linux: Not yet supported.
		 *
		 * Files arrive as file:// URLs via the existing "open-url" event:
		 * ```typescript
		 * Electrobun.events.on("open-url", (e) => {
		 *   if (e.data.url.startsWith("file://")) {
		 *     console.log("Opened file:", e.data.url);
		 *   }
		 * });
		 * ```
		 */
		fileAssociations?: Array<{
			/** File extensions without the leading dot (e.g., ["dotlock", "json"]) */
			ext: string[];
			/** Human-readable name for this file type (e.g., "DotLock Document") */
			name: string;
			/** The app's role for this file type. @default "Viewer" */
			role?: "Editor" | "Viewer" | "Shell" | "None";
			/**
			 * Path to an .icns file for this document type (macOS only).
			 * The file is automatically copied into the app bundle's Resources folder
			 * during the build. Only the filename (without path) is written to Info.plist.
			 */
			icon?: string;
		}>;
	};

	/**
	 * Bunny Ears / Carrot packaging metadata.
	 * This lets an Electrobun app also declare how it should behave when distributed as a Carrot.
	 */
	bunny?: {
		carrot?: {
			/**
			 * Carrot dependencies keyed by carrot id.
			 * Supports npm-style specifiers such as:
			 * - `file:../foundation-carrots/pty`
			 * - `workspace:*`
			 * - `^0.1.0`
			 */
			dependencies?: Record<string, string>;
		};
	};

	/**
	 * Build configuration options
	 */
	build?: {
		/**
		 * Main process implementation to build and package.
		 * - "bun": bundle and run the Bun main process entrypoint
		 * - "cottontail": bundle and run the Cottontail main process entrypoint
		 * - "zig": run the project-owned root `build.zig` and package its
		 *   `main` artifact
		 * - "rust": build and run a Cargo binary target
		 * - "go": compile and run the Go main process entrypoint
		 * - "odin": compile and run the Odin main process entrypoint
		 * @default "cottontail"
		 */
		mainProcess?: "bun" | "cottontail" | "zig" | "rust" | "go" | "odin";

		/**
		 * Bun main process build configuration.
		 * Used when `build.mainProcess` is set to `"bun"`.
		 */
		bun?: {
			/**
			 * Entry point for the main Bun process
			 * @default "src/bun/index.ts"
			 */
			entrypoint?: string;
		} & BundlerOptions;

		/**
		 * Cottontail main process build configuration.
		 * Used when `build.mainProcess` is set to `"cottontail"`.
		 */
		cottontail?: {
			/**
			 * Entry point for the main Cottontail process
			 * @default "src/bun/index.ts"
			 */
			entrypoint?: string;

			/**
			 * Ship the main process as precompiled JavaScriptCore bytecode
			 * instead of (or alongside) source. Cottontail-only.
			 *
			 * > **Coming soon.** This option is declared but not yet wired —
			 * > setting it is currently a no-op (the app ships normal source).
			 * > Build-time bytecode/obfuscation lands as a fast-follow after
			 * > Electrobun 2.0; the underlying Cottontail/JSC support is already
			 * > in place.
			 *
			 * - `false` (default): ship JavaScript source. Normal builds.
			 * - `true`: compile the main process to bytecode for faster startup
			 *   (skips parsing at launch). Source is still shipped as a fallback,
			 *   so the app stays fully debuggable and `Function.prototype.toString`
			 *   returns real source. Low risk — a version mismatch falls back to
			 *   parsing the source.
			 * - `"obfuscate"`: bytecode **and** strip the source. Ships only
			 *   bytecode, so the app's source is not distributed. Tradeoffs:
			 *   `Function.prototype.toString` returns `[native code]` (can break
			 *   libraries that introspect function source), error stacks lose
			 *   source frames, no sourcemaps, and there is no source fallback
			 *   (a runtime/version mismatch is a hard error rather than a reparse).
			 *   This is source obfuscation, not encryption.
			 *
			 * Dev builds (`--env=dev`) ignore this and always ship source so
			 * sourcemaps, the debugger, and hot reload keep working. The
			 * bytecode is generated against the exact Cottontail bundled into
			 * this app and regenerated on every build.
			 *
			 * @default false
			 */
			bytecode?: boolean | "obfuscate";
		} & BundlerOptions;

		/**
		 * Zig main process build configuration.
		 * Used when `build.mainProcess` is set to `"zig"`.
		 */
		zig?: {
			/**
			 * Exact Zig toolchain override. When omitted, Hutch uses the default
			 * declared by the selected Electrobun devkit.
			 */
			version?: string;
		};

		/**
		 * Rust main process build configuration.
		 * Used when `build.mainProcess` is set to `"rust"`.
		 */
		rust?: {
			/**
			 * Exact Rust toolchain override. When omitted, Hutch uses the default
			 * declared by the selected Electrobun devkit.
			 */
			version?: string;

			/**
			 * Project-owned Cargo manifest for the Rust main process.
			 * @default "Cargo.toml"
			 */
			manifest?: string;

			/**
			 * Cargo binary target staged as the Electrobun main process.
			 * @default "main"
			 */
			binary?: string;

		};

		/**
		 * Go main process build configuration.
		 * Used when `build.mainProcess` is set to `"go"`.
		 */
		go?: {
			/**
			 * Exact Go toolchain override. When omitted, Hutch uses the default
			 * declared by the selected Electrobun devkit.
			 */
			version?: string;

			/**
			 * Main package to compile from the project-owned Go module.
			 * Hutch runs `go build` from the project root and passes this value as
			 * the package argument; it never synthesizes a GOPATH or copies source.
			 * @default "./src/go"
			 */
			package?: string;

		};

		/**
		 * Odin main process build configuration.
		 * Used when `build.mainProcess` is set to `"odin"`.
		 *
		 * Note: Odin support has platform caveats (x64-only on Windows, MSVC
		 * Build Tools required on Windows). See docs for details.
		 */
		odin?: {
			/**
			 * Exact Odin toolchain release override. When omitted, Hutch uses the
			 * default declared by the selected Electrobun devkit.
			 */
			version?: string;

			/**
			 * Entry point for the main Odin process. May be a .odin file or a
			 * package directory; a file entrypoint compiles its containing
			 * directory as the root package.
			 * @default "src/odin/main.odin"
			 */
			entrypoint?: string;
		};

		/**
		 * Browser view build configurations.
		 * Each view accepts the supported bundler options in addition to the
		 * entrypoint.
		 */
		views?: {
			[viewName: string]: {
				/**
				 * Entry point for this view's TypeScript code
				 */
				entrypoint: string;
			} & ViewBundlerOptions;
		};

		/**
		 * Files to copy directly to the build output
		 * Key is a project source path. The value is a safe relative path inside
		 * the packaged application; absolute paths and `.` / `..` components are
		 * rejected.
		 */
		copy?: {
			[sourcePath: string]: string;
		};
		/**
		 * Project-relative output folder for the built application. Nested paths
		 * are allowed; absolute paths and `.` / `..` components are rejected.
		 * @default "build"
		 */
		buildFolder?: string;

		/**
		 * Project-relative output folder for distribution artifacts. Nested paths
		 * are allowed; absolute paths and `.` / `..` components are rejected.
		 * @default "artifacts"
		 */
		artifactFolder?: string;

		/**
		 * Additional file or directory paths to watch for changes during `electrobun dev --watch`.
		 * Paths are relative to the project root.
		 * Useful for files that affect your build but aren't listed as entrypoints or copy sources.
		 */
		watch?: string[];

		/**
		 * Glob patterns for files that should not trigger a rebuild when changed.
		 * Patterns are matched against project-relative paths.
		 * The `build/`, `artifacts/`, and `node_modules/` directories are always ignored automatically.
		 */
		watchIgnore?: string[];

		/**
		 * Carrot build configuration.
		 * When present, the build also produces a carrot artifact alongside the standalone app.
		 * Set `carrotOnly: true` to skip the standalone app build entirely.
		 */
		carrot?: {
			id: string;
			name: string;
			description?: string;
			mode?: "window" | "background";
			carrotOnly?: boolean;
			dependencies?: Record<string, string>;
			remoteUIs?: Record<string, CarrotUIDefinition>;
			slateUIs?: Record<string, CarrotUIDefinition>;
			contributions?: CarrotContributionsConfig;
		};

		/**
		 * macOS-specific build configuration
		 */
		mac?: {
			/**
			 * Enable code signing for macOS builds
			 * @default false
			 */
			codesign?: boolean;

			/**
			 * Create a DMG artifact for macOS builds.
			 * Disable this for local prototype builds that only need the app bundle and update archive.
			 * @default true
			 */
			createDmg?: boolean;

			/**
			 * Enable notarization for macOS builds (requires codesign)
			 * @default false
			 */
			notarize?: boolean;

			/**
			 * Bundle CEF (Chromium Embedded Framework) instead of using system WebView
			 * @default false
			 */
			bundleCEF?: boolean;

			/**
			 * Bundle Dawn (WebGPU) for GPU-native rendering
			 * @default false
			 */
			bundleWGPU?: boolean;

			/**
			 * Default renderer for webviews when not explicitly specified
			 * @default 'native'
			 */
			defaultRenderer?: "native" | "cef";

			/**
			 * Custom Chromium command-line flags to pass to CEF during initialization.
			 * Keys are flag names without the "--" prefix.
			 * - `true` — add a switch-only flag
			 * - `"value"` — add a flag with a value
			 * - `false` — remove a default flag set by Electrobun
			 *
			 * CEF remote debugging is automatic for dev builds and disabled by
			 * default for packaged builds. Set `"remote-debugging-port"` to a
			 * string port to opt in, or `false` to disable it explicitly.
			 *
			 * @example
			 * ```typescript
			 * chromiumFlags: {
			 *   "disable-gpu": false,               // remove Electrobun's default --disable-gpu
			 *   "remote-debugging-port": "9333",    // --remote-debugging-port=9333
			 * }
			 * ```
			 */
			chromiumFlags?: Record<string, string | boolean>;

			/**
			 * macOS entitlements for code signing
			 */
			entitlements?: Record<string, boolean | string | string[]>;

			/**
			 * Path to .iconset folder or .icon file (from Icon Composer)
			 * containing app icons.
			 *
			 * - `.iconset` folders are converted to .icns via iconutil
			 *   (requires Command Line Tools)
			 * - `.icon` files are compiled via actool, producing Assets.car
			 *   for Liquid Glass on macOS 26+ and a .icns fallback for older
			 *   macOS versions (requires Xcode)
			 *
			 * @default "icon.iconset"
			 */
			icons?: string;
		};

		/**
		 * Windows-specific build configuration
		 */
		win?: {
			/**
			 * Bundle CEF (Chromium Embedded Framework) instead of using WebView2
			 * @default false
			 */
			bundleCEF?: boolean;

			/**
			 * Bundle Dawn (WebGPU) for GPU-native rendering
			 * @default false
			 */
			bundleWGPU?: boolean;

			/**
			 * Default renderer for webviews when not explicitly specified
			 * @default 'native'
			 */
			defaultRenderer?: "native" | "cef";

			/**
			 * Custom Chromium command-line flags to pass to CEF during initialization.
			 * Keys are flag names without the "--" prefix.
			 * - `true` — add a switch-only flag
			 * - `"value"` — add a flag with a value
			 * - `false` — remove a default flag set by Electrobun
			 *
			 * CEF remote debugging is automatic for dev builds and disabled by
			 * default for packaged builds. Set `"remote-debugging-port"` to a
			 * string port to opt in, or `false` to disable it explicitly.
			 *
			 * @example
			 * ```typescript
			 * chromiumFlags: {
			 *   "disable-gpu": false,               // remove Electrobun's default --disable-gpu
			 *   "remote-debugging-port": "9333",    // --remote-debugging-port=9333
			 * }
			 * ```
			 */
			chromiumFlags?: Record<string, string | boolean>;

			/**
			 * WebView2 permissions to grant automatically without showing a prompt.
			 * This applies to every origin loaded in a native Windows webview, so only
			 * enable permissions that the application intentionally delegates to its
			 * web content. This option does not affect CEF webviews.
			 *
			 * @example ["camera", "microphone"]
			 * @default []
			 */
			autoGrantPermissions?: WindowsWebView2Permission[];

			/**
			 * Path to an application icon in ICO or PNG format. PNG input is
			 * converted to ICO by Hutch.
			 * Used for the installer/extractor wrapper, desktop shortcuts, and taskbar
			 * Should include multiple sizes (16x16, 32x32, 48x48, 256x256) for best results
			 * @example "assets/icon.ico"
			 */
			icon?: string;
		};

		/**
		 * Linux-specific build configuration
		 */
		linux?: {
			/**
			 * Bundle CEF (Chromium Embedded Framework) instead of using GTKWebKit
			 * Recommended on Linux for advanced layer compositing features
			 * @default false
			 */
			bundleCEF?: boolean;

			/**
			 * Bundle Dawn (WebGPU) for GPU-native rendering
			 * @default false
			 */
			bundleWGPU?: boolean;

			/**
			 * Default renderer for webviews when not explicitly specified
			 * @default 'native'
			 */
			defaultRenderer?: "native" | "cef";

			/**
			 * Emit an expanded Flatpak-builder recipe alongside the normal Linux
			 * artifacts. This is an opt-in packaging MVP: Hutch writes a manifest
			 * and `/app` payload but does not invoke `flatpak-builder`.
			 */
			flatpak?: {
				/** Enable Flatpak recipe generation. @default false */
				enabled: boolean;

				/** Output directory relative to `build.artifactFolder`. @default "flatpak" */
				outputPath?: string;

				/** Flatpak runtime identifier. @default "org.freedesktop.Platform" */
				runtime?: string;

				/** Flatpak runtime branch. @default "25.08" */
				runtimeVersion?: string;

				/** Flatpak SDK identifier. @default "org.freedesktop.Sdk" */
				sdk?: string;

				/** Override the manifest's default sandbox finish arguments. */
				finishArgs?: string[];
			};

			/**
			 * Custom Chromium command-line flags to pass to CEF during initialization.
			 * Keys are flag names without the "--" prefix.
			 * - `true` — add a switch-only flag
			 * - `"value"` — add a flag with a value
			 * - `false` — remove a default flag set by Electrobun
			 *
			 * CEF remote debugging is automatic for dev builds and disabled by
			 * default for packaged builds. Set `"remote-debugging-port"` to a
			 * string port to opt in, or `false` to disable it explicitly.
			 *
			 * @example
			 * ```typescript
			 * chromiumFlags: {
			 *   "disable-gpu": false,               // remove Electrobun's default --disable-gpu
			 *   "remote-debugging-port": "9333",    // --remote-debugging-port=9333
			 * }
			 * ```
			 */
			chromiumFlags?: Record<string, string | boolean>;

			/**
			 * Path to application icon (PNG format recommended)
			 * Used for desktop entries, window icons, and taskbar
			 * Should be at least 256x256 pixels for best results
			 * @example "assets/icon.png"
			 */
			icon?: string;
		};
	};

	/**
	 * Runtime behaviour configuration.
	 * These values are copied into build.json and available to the main process at runtime.
	 * You can add arbitrary keys here and access them via BuildConfig.
	 */
	runtime?: {
		/**
		 * Quit the application when the last BrowserWindow is closed.
		 * @default true
		 */
		exitOnLastWindowClosed?: boolean;

		[key: string]: unknown;
	};

	/**
	 * Build scripts configuration
	 */
	scripts?: {
		/**
		 * Script to run before the build starts
		 * Can be a path to a script file
		 */
		preBuild?: string;

		/**
		 * Script to run after build completes
		 * Can be a path to a script file
		 */
		postBuild?: string;

		/**
		 * Script to run after the app is wrapped (macOS .app bundle created)
		 * Can be a path to a script file
		 */
		postWrap?: string;

		/**
		 * Script to run after packaging is complete
		 * Can be a path to a script file
		 */
		postPackage?: string;
	};

	/**
	 * Release and distribution configuration
	 */
	release?: {
		/**
		 * Base URL for artifact distribution (e.g., S3 bucket, GitHub Releases)
		 * Used for auto-updates and patch generation
		 */
		baseUrl?: string;
		/**
		 * Generate delta patch files by diffing against the previous release.
		 * Disable to skip patch generation for local canary/stable testing.
		 * @default true
		 */
		generatePatch?: boolean;
	};
}
